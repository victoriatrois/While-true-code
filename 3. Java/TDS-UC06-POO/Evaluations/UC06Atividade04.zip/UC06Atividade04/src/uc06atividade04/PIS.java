/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uc06atividade04;

/**
 *
 * @author v3gc
 */
public class PIS extends TributosParaFinanciamentoDeDireitosDosTrabalhadores {
    public PIS() {
        this.setSigla("PIS");
        this.setDescricao("Programa de Integração Social");
        this.setAliquota(1.65f);
    }
}
