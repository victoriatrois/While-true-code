/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uc06atividade04;

/**
 *
 * @author v3gc
 */
public class Cofins extends TributosParaFinanciamentoDeDireitosDosTrabalhadores {
    public Cofins() {
        this.setSigla("Cofins");
        this.setDescricao("Contribuição para o Financiamento da Seguridade Social");
        this.setAliquota(7.6f);
    }
}
