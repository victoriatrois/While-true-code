/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package uc06atividade04;

/**
 *
 * @author v3gc
 */
public interface Calculador {
    public float calculaImposto();
}
