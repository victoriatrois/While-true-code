/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uc06atividade05;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Scanner;


/**
 *
 * @author v3gc
 */
public class Pedido {

    public static int getNumeroDoPedido() {
        return numeroDoPedido;
    }

    public static void setNumeroDoPedido(int aNumeroDoPedido) {
        numeroDoPedido = aNumeroDoPedido;
    }
    Scanner entrada = new Scanner(System.in);
    
    public static String removeDiacriticos(String s) {
	    s = Normalizer.normalize(s, Normalizer.Form.NFD);
	    s = s.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
	    return s;
    }
    
    private int numeroDaMesa;
    private static int numeroDoPedido = 0;
    private Produto itemEscolhido;
    private int quantidadeDoItem;
    private ArrayList<Produto> pedido = new ArrayList<>();
    private float valorTotal;

    public int getNumeroDaMesa() {
        return numeroDaMesa;
    }

    public void setNumeroDaMesa(int numeroDaMesa) {
        this.numeroDaMesa = numeroDaMesa;
    }
    
    public float fechaPedido() {
        for (Produto cadaItem : pedido) {
            this.valorTotal += quantidadeDoItem * cadaItem.getPrecoProduto();
        }
        return this.valorTotal;
    }

    /*public Produto getItemEscolhido() {
        return itemEscolhido;
    }

    public void setItemEscolhido(Produto itemEscolhido) {
        this.itemEscolhido = itemEscolhido;
    }*/

    public Produto getItemEscolhido(int indice) {
        return pedido.get(indice);
    }

    public void adicionaProdutoAoPedido (Produto itemEscolhido) {        
        this.pedido.add(itemEscolhido);
    }
    
    public int getQuantidadeDoItem() {
        return quantidadeDoItem;
    }

    public void setQuantidadeDoItem(int quantidadeDoItem) {
        this.quantidadeDoItem = quantidadeDoItem;
    }

    public ArrayList<Produto> getPedido() {
        return pedido;
    }

    public void setPedido(ArrayList<Produto> pedido) {
        this.pedido = pedido;
    }

    public float getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(float valorTotal) {
        this.valorTotal = valorTotal;
    }
    
    
    
    public void cancelarPedido() {
        if (pedido.isEmpty()) {
            System.out.println("Não há pedidos cadastrados.");
            
        } else {
            for (Produto cadaItem : pedido) {
                System.out.println("*** Resumo do Pedido ***");
                System.out.println("Mesa: " + this.getNumeroDaMesa());
                System.out.println("Código: " + this.itemEscolhido.getCodigoDoProduto());
                System.out.println("Descrição: " + this.itemEscolhido.getNomeProduto());
                System.out.println("Quantidade: " + this.getQuantidadeDoItem());
                //falta o preço total
            }
            
            System.out.print("Deseja cancelar o pedido? Digite \"Sim\" ou \"Não\". ");
            String statusPedido = removeDiacriticos(entrada.nextLine()).toLowerCase();

            while (! statusPedido.equals("sim") && ! statusPedido.equals("nao")) {
                System.out.println("Entrada inválida. Digite \"Sim\" ou \"Não\".");
            }
            
            if (statusPedido.equals("nao")) {
                pedido.clear();
                    
            }

        }
    }
    
    public void incrementaNumeroDoPedido() {
        numeroDoPedido++;
    }
    
    public void cancelaItem(Produto itemEscolhido) {
        pedido.remove(itemEscolhido);
    }

    @Override
    public String toString() {
        return "Pedido{" + "entrada=" + entrada + ", numeroDaMesa=" + numeroDaMesa + ", itemEscolhido=" + itemEscolhido + ", quantidadeDoItem=" + quantidadeDoItem + ", pedido=" + pedido + ", valorTotal=" + valorTotal + '}';
    }
    
    

}
