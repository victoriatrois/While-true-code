/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uc06atividade02;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author v3gc
 */
public class Trajetoria {
    Scanner entrada = new Scanner(System.in);
    
    private Ponto2D coordenada;
    private ArrayList<Ponto2D> coordenadas = new ArrayList();
    

    public Trajetoria() {
        
    }
    
    public Ponto2D getCoordenada() {
        return coordenada;
    }
    
    public void setCoordenada(Ponto2D eixosXY) {
        this.coordenada = eixosXY;
    }
    
    public ArrayList<Ponto2D> getCoordenadas() {
        return coordenadas;
    }

    public void setCoordenadas(ArrayList<Ponto2D> coordenadas) {
        this.coordenadas = coordenadas;
    }
    
    public ArrayList<Ponto2D> defineCoordenadas(int numeroDeCordenadas) {
        ArrayList<Ponto2D> levantamentoDeCoordenadas = new ArrayList<>();
        
        for (int coordenadaAtual = 0; coordenadaAtual < numeroDeCordenadas; coordenadaAtual++) {
            System.out.println("Digite os eixos XY da " + (coordenadaAtual + 1) + "ª coordenada:");
            Ponto2D coordenadasDaTrajetoria = new Ponto2D();
            
            System.out.print("Eixo X: ");
            coordenadasDaTrajetoria.setEixoX(entrada.nextDouble());
            
            System.out.print("Eixo Y: ");
            coordenadasDaTrajetoria.setEixoY(entrada.nextDouble());
            
            levantamentoDeCoordenadas.add(coordenadasDaTrajetoria);
        }
        
        return levantamentoDeCoordenadas;
    }
    
    public void exibePontos(ArrayList<Ponto2D> levantamentoDeCoordenadas) {
        for (int elementoAtual = 0; elementoAtual < levantamentoDeCoordenadas.size(); elementoAtual++) {
            System.out.print("(");
            System.out.print(levantamentoDeCoordenadas.get(elementoAtual).getEixoX());
            System.out.print(" , ");
            System.out.print(levantamentoDeCoordenadas.get(elementoAtual).getEixoY());
            System.out.print(")\n");
        }
    }

    public void calculaDistanciaEntreCoordenadas(ArrayList<Ponto2D> levantamentoDeCoordenadas) {
        for (int elementoAtual = 0; elementoAtual < levantamentoDeCoordenadas.size(); elementoAtual++) {
            System.out.print("(");
            System.out.print(levantamentoDeCoordenadas.get(elementoAtual).getEixoX());
            System.out.print(" , ");
            System.out.print(levantamentoDeCoordenadas.get(elementoAtual).getEixoY());
            System.out.print(")\n");
        }
    }
    
    public void exibeDistanciaPontoAPonto(ArrayList<Ponto2D> levantamentoDeCoordenadas) {
        for (int elementoAtual = 0; elementoAtual < levantamentoDeCoordenadas.size(); elementoAtual++) {
            int elementoSeguinte = elementoAtual + 1;
            
            double elementoAtualEixoX = levantamentoDeCoordenadas.get(elementoAtual).getEixoX();
            double elementoAtualEixoY = levantamentoDeCoordenadas.get(elementoAtual).getEixoY();
            double elementoSeguinteEixoX = levantamentoDeCoordenadas.get(elementoSeguinte).getEixoX();
            double elementoSeguinteEixoY = levantamentoDeCoordenadas.get(elementoSeguinte).getEixoY();
            
            System.out.print("(");
            System.out.print(levantamentoDeCoordenadas.get(elementoAtual).getEixoX());
            System.out.print(" , ");
            System.out.print(levantamentoDeCoordenadas.get(elementoAtual).getEixoY());
            System.out.print(") a (" );
            System.out.print(levantamentoDeCoordenadas.get(elementoSeguinte).getEixoX());
            System.out.print(" , ");
            System.out.print(levantamentoDeCoordenadas.get(elementoSeguinte).getEixoY());
            System.out.print(") a - distância: " );
            
            System.out.println(levantamentoDeCoordenadas.get(elementoAtual).calculaDistancia(elementoAtualEixoX, elementoAtualEixoY, elementoSeguinteEixoX, elementoSeguinteEixoY).toString());
        }
    }
    
    public Double calculaDistanciaTotal(ArrayList<Ponto2D> levantamentoDeCoordenadas) {
        ArrayList<Double> distanciasEntrePontos = new ArrayList<>();
        Double distanciaTotal = 0.0;
        
        for (int elementoAtual = 0; elementoAtual < levantamentoDeCoordenadas.size(); elementoAtual++) {
            int elementoSeguinte = elementoAtual + 1;
            
            double elementoAtualEixoX = levantamentoDeCoordenadas.get(elementoAtual).getEixoX();
            double elementoAtualEixoY = levantamentoDeCoordenadas.get(elementoAtual).getEixoY();
            double elementoSeguinteEixoX = levantamentoDeCoordenadas.get(elementoSeguinte).getEixoX();
            double elementoSeguinteEixoY = levantamentoDeCoordenadas.get(elementoSeguinte).getEixoY();
            
            for(int i = 0; i < levantamentoDeCoordenadas.size(); i++) {
                distanciasEntrePontos.add(levantamentoDeCoordenadas.get(elementoAtual).calculaDistancia(elementoAtualEixoX, elementoAtualEixoY, elementoSeguinteEixoX, elementoSeguinteEixoY));
                distanciaTotal += distanciasEntrePontos.get(i);
            }
        }
        return distanciaTotal;
    }
    
    
    public void redimensionaRota() {
        
    }
}
