/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uc06atividade02;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author v3gc
 */
public class Ponto2D {
    private double eixoX;
    private double eixoY;
    

    public Ponto2D(double eixoX, double eixoY) {
        this.eixoX = eixoX;
        this.eixoY = eixoY;
    }
    
    public Ponto2D() {
        
    }

    public double getEixoX() {
        return eixoX;
    }

    public void setEixoX(double eixoX) {
        this.eixoX = eixoX;
    }

    public double getEixoY() {
        return eixoY;
    }

    public void setEixoY(double eixoY) {
        this.eixoY = eixoY;
    }
    
    public Double calculaDistancia(double xDeA, double yDeA, double xDeB, double yDeB) {
        double distanciaEixosX = xDeB - xDeA;
        double distanciaEixosY = yDeB - yDeA;
        
        double distanciaEntreAB = Math.sqrt((Math.pow(distanciaEixosX, 2)) + (Math.pow(distanciaEixosY, 2)));
        
        return distanciaEntreAB;
    }
    
    public void multiplicaCoordenadaA (double multiplicador, double xDeA, double yDeA) {
        double eixoXMultiplicado = multiplicador * xDeA;
        double eixoYMultiplicado = multiplicador * yDeA;
        System.out.println("A coordenada dada multiplicada por " + multiplicador + " é X: " + eixoXMultiplicado + ", Y: " + eixoYMultiplicado + ".");
    }
    
    public void mostraCoordenadas() {
        System.out.println("(X:" + this.eixoX + " , Y:" + this.eixoY + ").");
        
    }
}
