/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package uc06atividade02;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author v3gc
 */
public class UC06Atividade02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("Classe Ponto2D");
        Ponto2D pontoA = new Ponto2D(1.2, 1.5);
        pontoA.mostraCoordenadas();
        pontoA.calculaDistancia(0, 0, 0, 0);

        
        System.out.println("\nClasse Trajetoria");
        Trajetoria GPS = new Trajetoria();
        //GPS.exibePontos(GPS.defineCoordenadas(4));
        //GPS.exibeDistanciaPontoAPonto(GPS.defineCoordenadas(4));
        GPS.calculaDistanciaEntreCoordenadas(GPS.defineCoordenadas(4));
        
        
        
    }
    
}
