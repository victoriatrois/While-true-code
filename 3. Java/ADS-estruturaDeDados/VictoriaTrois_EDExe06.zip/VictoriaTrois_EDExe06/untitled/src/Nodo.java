public class Nodo {
    int valor;
    int altura;
    Nodo nodoEsquerdo, nodoDireito;

    Nodo(int valor) {
        this.valor = valor;
        altura = 1;
    }
}
