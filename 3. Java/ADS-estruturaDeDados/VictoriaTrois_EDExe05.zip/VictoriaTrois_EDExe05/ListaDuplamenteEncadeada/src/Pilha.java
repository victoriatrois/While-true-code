public class Pilha extends ListaDuplamenteEncadeada {
}
