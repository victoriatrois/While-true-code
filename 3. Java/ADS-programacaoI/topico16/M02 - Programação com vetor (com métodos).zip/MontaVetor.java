import java.util.Scanner;

public class MontaVetor {
    
    public static void daInstrucao(String mensagem) {
        System.out.println(mensagem);
    }
    // TODO: método leitor de inteiros
    public static int leInteiro(int valor) {
        valor = valor;
            
        return valor;
        
    }
    
    // TODO: método leitor de doubles
    public static double leDouble(double valor) {
        valor = valor;
        
        return valor;
    }
    
    // TODO: método de exibição do vetor
    public static void mostraVetor (double[] vetor) {
        for (int i = 0; i < vetor.length; i++) {
            System.out.printf("v[" + i + "] = %.4f %n", vetor[i]);
        }
    }
    
    // TODO: método principal
    public static void main (String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        // TODO: ler um valor inteiro positivo N
        final int N;
        daInstrucao("Insira um valor inteiro POSITIVO: ");
        N = leInteiro(entrada.nextInt());
        if (N < 0) {
            System.out.println("-");
        } else {
            // TODO: criar um vetor do tamanho N
            double[] v;
            v = new double[N];
            
            // TODO: ler um valor double e  atribuir o valor double à posição 0 do vetor
            daInstrucao("Insira o primeiro valor do seu vetor: ");
            v[0] = leDouble(entrada.nextDouble());
            
            // TODO: preencher os elementos seguintes com a metade do seu elemento anterior
            for (int i = 1; i < v.length; i++) {
                v[i] = v[i-1]/2;
            }
            // TODO: mostrar todo o vetor com cada elemento tendo 4 casas decimais
            mostraVetor(v);
        }
    }
}