import java.util.Scanner;

public class cadastraDezDistintos {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int[] valor = new int[10];
        
        for (int i = 0; i < valor.length; i++) { // 1 comando antes de entrar no for, que ocorre uma vez unica vez, 2 while dentro do for, 3 ultimo comando do bloco
            valor[i] = entrada.nextInt();
            if (valor[i] == 0) {
                i = valor.length; // escapa do primeiro for
            } else {
                for (int j = 0; j < i; j++) { // percorre os elementos já preenchidos para testar se o novo valor é válido
                    if (valor[i] == valor[j]) {
                        i--;
                        j = i; // escapa do segundo for
                    } 
                }
            }
        }
        
        for(int i = 0; i < valor.length; i++) {
            System.out.print(valor[i] + " ");
        }
    }
}
