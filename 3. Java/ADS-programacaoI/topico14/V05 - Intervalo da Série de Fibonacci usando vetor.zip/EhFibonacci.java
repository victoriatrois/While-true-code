import java.util.Scanner;

public class EhFibonacci {
    public static void main (String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int numeroInicial;
        int numeroFinal;
        int[] fibonacci = new int[30];
        int p=-1,u=0;
        
        fibonacci[0] = 0;
        fibonacci[1] = 1;
        for(int i = 2; i < fibonacci.length; i++) {
            fibonacci[i] = fibonacci[i - 1] + fibonacci[i - 2];
        }
        
        numeroInicial = entrada.nextInt();
        numeroFinal = entrada.nextInt();
        
        
        
        if (numeroInicial < fibonacci[0] || numeroFinal > fibonacci[29] || numeroInicial > numeroFinal) {
            System.out.print("erro");
        } else if (numeroInicial == numeroFinal) {
            System.out.print("-");
        } else {
            for(int i = 0; i < fibonacci.length; i++) {
                if ((fibonacci[i] >= numeroInicial) && (fibonacci[i] <= numeroFinal)) {
                    System.out.print (fibonacci[i] + " ");
                    u = i;
                    if(p==-1){
                        p = i;
                    }
                }
            }
            System.out.print ("- "+p+"-"+u);
        }
    }
}