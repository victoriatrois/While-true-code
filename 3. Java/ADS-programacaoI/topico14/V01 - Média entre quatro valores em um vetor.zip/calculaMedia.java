import java.util.Scanner;

public class calculaMedia {
    public static void main (String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        float[] valor = new float[5];
        
        //preenchendo o vetor com laço:
        for (int i = 0; i < 4; i++) {
            valor[i] = entrada.nextFloat();
        }
        
        // preenchendo o vetor manualmente:
        // valor[0] = entrada.nextFloat();
        // valor[1] = entrada.nextFloat();
        // valor[2] = entrada.nextFloat();
        // valor[3] = entrada.nextFloat();
        
        valor[4] = (valor[0] + valor[1] + valor[2] + valor[3]) / 4;
        
        System.out.printf("%.2f", valor[4]);
    }
}
