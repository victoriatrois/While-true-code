import java.util.Scanner;

public class produtoEntreDoisFatores {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int primeiroFator = entrada.nextInt();
        
        int segundoFator = entrada.nextInt();
        
        int produto = primeiroFator*segundoFator;
        System.out.println(produto);
    }
}