import java.util.Scanner;

public class AreaCirculo {
    public static void main (String[] args) {
        Scanner entrada = new Scanner(System.in);
        double PI = 3.1415;
        
        double diametro = entrada.nextFloat();
        
        double raio = diametro / 2;
        double raioAoQuadrado = Math.pow(raio, 2);
        double areaCirculo =  PI * raioAoQuadrado;
        
        System.out.printf("%.2f", areaCirculo);
    }
}