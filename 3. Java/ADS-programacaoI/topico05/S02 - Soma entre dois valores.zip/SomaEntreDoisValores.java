import java.util.Scanner;

public class SomaEntreDoisValores {
    
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int primeiraParcela = entrada.nextInt();
        
        int segundaParcela = entrada.nextInt();
        
        int soma = primeiraParcela + segundaParcela;
        
        System.out.println(soma);
    }
}