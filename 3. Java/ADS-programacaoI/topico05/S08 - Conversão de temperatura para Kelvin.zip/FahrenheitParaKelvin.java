import java.util.Scanner;

public class FahrenheitParaKelvin {
    public static void main (String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        float temperaturaEmFahrenheit = entrada.nextFloat();
        float temperaturaEmKelvin = (temperaturaEmFahrenheit + 459.4f) * (5/9f);
        
        System.out.printf("%.1f", temperaturaEmKelvin);
    }
}