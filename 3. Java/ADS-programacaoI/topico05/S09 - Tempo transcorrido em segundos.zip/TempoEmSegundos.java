import java.util.Scanner;

public class TempoEmSegundos {
    public static void main (String[]args) {
        Scanner entrada = new Scanner(System.in);
        
        int horasPercorridas = entrada.nextInt();
        int minutosPercorridos = entrada.nextInt();
        int segundosPercorridos = entrada.nextInt();
        
        int totalDeHorasEmSegundos = horasPercorridas * 3600;
        int totalDeMinutosEmSegundos = minutosPercorridos * 60;
        
        int segundosTotais = totalDeHorasEmSegundos + totalDeMinutosEmSegundos + segundosPercorridos;
        
        System.out.print(segundosTotais);
    }
}