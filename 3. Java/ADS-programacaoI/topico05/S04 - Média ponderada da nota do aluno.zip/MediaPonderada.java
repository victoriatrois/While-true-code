import java.util.Scanner;

public class MediaPonderada {
    public static void main (String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        float primeiraNota = entrada.nextFloat();
        float pesoPrimeiraNota = entrada.nextFloat();
        
        float segundaNota = entrada.nextFloat();
        float pesoSegundaNota = entrada.nextFloat();
        
        float terceiraNota = entrada.nextFloat();
        float pesoTerceiraNota = entrada.nextFloat();
        
        float mediaPonderada = ((primeiraNota * pesoPrimeiraNota) + (segundaNota * pesoSegundaNota) + (terceiraNota * pesoTerceiraNota)) / (pesoPrimeiraNota + pesoSegundaNota + pesoTerceiraNota);
        System.out.print(mediaPonderada);
    }
}