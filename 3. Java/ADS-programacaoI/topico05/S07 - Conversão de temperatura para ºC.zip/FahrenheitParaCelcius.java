import java.util.Scanner;

public class FahrenheitParaCelcius {
    public static void main (String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        float temperaturaEmFahrenheit = entrada.nextFloat();
        float temperaturaEmCelcius = (temperaturaEmFahrenheit - 32) / 1.8f;
        
        System.out.printf("%.1f", temperaturaEmCelcius);
    }
}