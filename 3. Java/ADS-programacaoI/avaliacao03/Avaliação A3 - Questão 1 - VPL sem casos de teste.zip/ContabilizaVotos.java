import java.util.Scanner;

public class ContabilizaVotos {
    public static void main (String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int voto;
        int candidato1;
        int candidato2;
        int candidato3;
        int candidato4;
        int candidato5;
        int totalDeVotos;
        float percentualCandidato1;
        float percentualCandidato2;
        float percentualCandidato3;
        float percentualCandidato4;
        float percentualCandidato5;
        
        voto = -1;
        candidato1 = 0;
        candidato2 = 0;
        candidato3 = 0;
        candidato4 = 0;
        candidato5 = 0;
        totalDeVotos = 0;
        percentualCandidato1 = 0.0f;
        percentualCandidato2 = 0.0f;
        percentualCandidato3 = 0.0f;
        percentualCandidato4 = 0.0f;
        percentualCandidato5 = 0.0f;
        
        while (voto != 0) {
            System.out.print("Entre um voto: ");
            voto = entrada.nextInt();
            
            if (voto == 1) {
                candidato1++;
            } else if (voto == 2) {
                candidato2++;
            } else if (voto == 3) {
                candidato3++;
            } else if (voto == 4) {
                candidato4++;
            } else if (voto == 5) {
                candidato5++;
            }
        }
        totalDeVotos = candidato1 + candidato2 + candidato3 + candidato4 + candidato5;
        
        percentualCandidato1 = (candidato1*100.0f)/(float)totalDeVotos;
        percentualCandidato2 = (candidato2*100.0f)/(float)totalDeVotos;
        percentualCandidato3 = (candidato3*100.0f)/(float)totalDeVotos;
        percentualCandidato4 = (candidato4*100.0f)/(float)totalDeVotos;
        percentualCandidato5 = (candidato5*100.0f)/(float)totalDeVotos;
        
        System.out.println("**** Resultados ****");
        System.out.println("candidato 1: " + candidato1 + " " + percentualCandidato1 +"%");
        System.out.println("candidato 2: " + candidato2 + " " + percentualCandidato2 +"%");
        System.out.println("candidato 3: " + candidato3 + " " + percentualCandidato3 +"%");
        System.out.println("candidato 4: " + candidato4 + " " + percentualCandidato4 +"%");
        System.out.println("candidato 5: " + candidato5 + " " + percentualCandidato5 +"%");
    }
}