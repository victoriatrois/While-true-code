import java.util.Scanner;

public class SelecionaOMaior {
    public static void main (String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int numeroAConferir;
        int oMaior;
        
        numeroAConferir = 1;
        oMaior = 0;
        
        while (numeroAConferir != 0) {
            numeroAConferir = entrada.nextInt();
            
            if (numeroAConferir < 0) {
                if ((numeroAConferir < -1) && (numeroAConferir > oMaior)) {
                    oMaior = numeroAConferir;
                } else {
                    oMaior = -1;
                }
            } else {
                if (numeroAConferir > 0) {
                    if ((numeroAConferir > oMaior)) {
                    oMaior = numeroAConferir;
                    }
                }
            }
        }
        if (oMaior == 0) {
            System.out.print("erro");
        } else {
            System.out.print(oMaior);
        }
    }
}