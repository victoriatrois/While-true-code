import java.util.Scanner;

public class NumeraIntervalo {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int numeros;
        int contador;
        
        numeros = 1;
        contador = 0;
        
        if (numeros >= 1) {
            while (numeros != 0 ) {
                numeros = entrada.nextInt();
                
                if (numeros > 99 && numeros < 201) {
                    contador++;
                }
            }
        }
        System.out.print(contador);
    }
}