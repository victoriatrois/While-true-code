import java.util.Scanner;

public class EhFibonacci {
    public static void main (String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int numeroInicial;
        int numeroFinal;
        int contador;
        int numeroAnterior;
        int fibonacci;
        int proximoNumero;
        
        numeroInicial = entrada.nextInt();
        numeroFinal = entrada.nextInt();
        
        numeroAnterior = 0;
        fibonacci = 0;
        proximoNumero = 1;
        
        for (contador = 0; contador <= numeroFinal; contador++) {
            if (fibonacci >= numeroInicial && fibonacci <= numeroFinal) {
                System.out.print(fibonacci + " ");
            }
            
            if (numeroInicial == 0 && fibonacci == 1) {
                System.out.print(1 + " ");
            }
            
            fibonacci += 1;
            fibonacci = numeroAnterior + proximoNumero;
            numeroAnterior = proximoNumero;
            proximoNumero = fibonacci;
        }
            
    }
}