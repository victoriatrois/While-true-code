import java.util.Scanner;

public class MenorSuperaMaior {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int alturaPrimeiraArvore;
        int centimetrosQueCrescePrimeiraArvore;
        
        int alturaSegundaArvore;
        int centimetrosQueCresceSegundaArvore;
        
        int alturaMenorArvore;
        int crescimentoMenorArvore;
        
        int alturaMaiorArvore;
        int crescimentoMaiorArvore;
        
        int anosParaPassar;
        
        anosParaPassar = 1;
        alturaMenorArvore = 0;
        alturaMaiorArvore = 0;
        
        alturaPrimeiraArvore = entrada.nextInt();
        centimetrosQueCrescePrimeiraArvore = entrada.nextInt();
        alturaSegundaArvore = entrada.nextInt();
        centimetrosQueCresceSegundaArvore = entrada.nextInt();
        
        if (alturaPrimeiraArvore == alturaSegundaArvore) {
            if (centimetrosQueCrescePrimeiraArvore == centimetrosQueCresceSegundaArvore) {
                System.out.print("nunca");
            } else {
                System.out.print(anosParaPassar);
            }
        } else {
            if (alturaPrimeiraArvore < alturaSegundaArvore) {
                alturaMenorArvore = alturaPrimeiraArvore;
                crescimentoMenorArvore = centimetrosQueCrescePrimeiraArvore;
                
                alturaMaiorArvore = alturaSegundaArvore;
                crescimentoMaiorArvore = centimetrosQueCresceSegundaArvore;
                
            } else {
                alturaMenorArvore = alturaSegundaArvore;
                crescimentoMenorArvore = centimetrosQueCresceSegundaArvore;
                
                alturaMaiorArvore = alturaPrimeiraArvore;
                crescimentoMaiorArvore = centimetrosQueCrescePrimeiraArvore;
            }
            
            if (alturaMenorArvore < alturaMaiorArvore && crescimentoMenorArvore <= crescimentoMaiorArvore) {
                System.out.print("nunca");
            } else {
                while ((alturaMenorArvore + crescimentoMenorArvore) <= (alturaMaiorArvore + crescimentoMaiorArvore)) {
                    alturaMenorArvore += crescimentoMenorArvore;
                    alturaMaiorArvore += crescimentoMaiorArvore;
                    anosParaPassar++;
                }
                System.out.print(anosParaPassar);
            }
        }
    }
}