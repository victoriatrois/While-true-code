import java.util.Scanner;

public class SomaValores {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int[] valor1 = new int[10];
        int[] valor2 = new int[10];
        int[] valor3 = new int[10];
        
        // TODO: ler 10 primeiros valores em um vetor;
        for (int i = 0; i < valor1.length; i++) {
            valor1[i] = entrada.nextInt();
        }
        // TODO: ler 10 seguintes valores em um segundo vetor;
        for (int i = 0; i < valor1.length; i++) {
            valor2[i] = entrada.nextInt();
        }
        // TODO: somar o primeiro elemento do primeiro vetor com o primeiro elemento do segundo vetor;
        for (int i = 0; i < valor1.length; i++) {
            valor3[i] = valor1[i] + valor2[i];
        }
        // TODO: exibir o terceiro vetor na tela OBS: separar os valores com um ESPAÇO;
        for (int i = 0; i < valor1.length; i++) {
            System.out.print(valor3[i] + " ");
        }
    }
}