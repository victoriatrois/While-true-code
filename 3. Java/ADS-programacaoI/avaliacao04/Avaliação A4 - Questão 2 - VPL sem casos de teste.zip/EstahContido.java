import java.util.Scanner;

public class EstahContido {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int[] valor;
        int valorATestar;
        boolean estahContido;
        int posicaoPresente;
        
        valor = new int[10];
        valorATestar = 0;
        estahContido = false;
        posicaoPresente = 0;
        
        // TODO: Ler 10 valores;
        for (int i = 0; i < valor.length; i++) {
            valor[i] = entrada.nextInt();
        }
        // TODO: Mostrar o vetor armazenado;
        for (int i = 0; i < valor.length; i++) {
            System.out.print(valor[i] + " ");
        }
        // TODO: Ler um novo valor;
        System.out.print("\n");
        valorATestar = entrada.nextInt();
        // TODO: Verificar se o valor lido é encontrado no vetor existente;
        for (int i = 0; i < valor.length; i++) {
        // TODO: Verifica se estã contido
            if (valor[i] == valorATestar) {
                estahContido = true;
                posicaoPresente = i;
            }
        }
        // TODO: Se estiver presente mostrar sua posição;
        if (estahContido) {
            System.out.print (posicaoPresente);
        } else {
        // TODO: Se não estiver contido exiba -1;
                System.out.print(" -1");
        }
    }
}