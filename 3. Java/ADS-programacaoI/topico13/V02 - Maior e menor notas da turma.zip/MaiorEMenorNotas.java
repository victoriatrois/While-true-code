import java.util.Scanner;

public class MaiorEMenorNotas {
    public static void main (String[] args) {
        Scanner entrada = new Scanner(System.in);
        float menorNota;
        float maiorNota;
        int matriculaMenorNota;
        int matriculaMaiorNota;
        
        matriculaMenorNota = 0;
        matriculaMaiorNota = 0;
        menorNota = 10;
        maiorNota = 0;
        
        float[] nota = new float[10];
        
        for (int i = 0; i < 10; i++) {
            nota[i] = entrada.nextFloat();
            
            if (nota[i] > maiorNota) {
                maiorNota = nota[i];
                matriculaMaiorNota = i + 1;
            } else if (nota[i] < menorNota) {
                menorNota = nota[i];
                matriculaMenorNota = i + 1;
            }
        }

        System.out.printf(matriculaMenorNota + " %.2f ", menorNota);
        System.out.printf(matriculaMaiorNota + " %.2f", maiorNota);
        
    }
}
