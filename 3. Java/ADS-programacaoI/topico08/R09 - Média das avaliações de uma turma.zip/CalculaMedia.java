import java.util.Scanner;

public class CalculaMedia {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int numeroDeAlunos;
        float somaNotas;
        float media;
        
        somaNotas = 0;
        
        System.out.print("Quantos alunos há na sua turma? ");
        numeroDeAlunos = entrada.nextInt();
        
        for (int contador = 0; contador < numeroDeAlunos; contador++) {
            somaNotas += entrada.nextFloat();
        }
        media = somaNotas / (float)numeroDeAlunos;
        System.out.print(media);
    }
}