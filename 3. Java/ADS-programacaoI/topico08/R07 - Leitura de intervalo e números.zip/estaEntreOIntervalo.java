import java.util.Scanner;

public class estaEntreOIntervalo {
    public static void main (String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int numeroInicial;
        int numeroFinal;
        int numeroAConferir;
        int contador;
        
        numeroAConferir = 1;
        contador = 0;
        
        System.out.print("Entre o valor inicial: ");
        numeroInicial = entrada.nextInt();
        System.out.print("Entre o valor final: ");
        numeroFinal = entrada.nextInt();
        
        if (numeroInicial < 0) {
            System.out.print("inválido");
        } else {
            if (numeroAConferir >= 1) {
                System.out.println("Entre os valores que deseja conferir. Para sair, digite zero.");
                while (numeroAConferir != 0 ) {
                    numeroAConferir = entrada.nextInt();
                    
                    if (numeroAConferir >= numeroInicial && numeroAConferir <= numeroFinal) {
                        contador++;
                    }
                }
            }
                
            System.out.print(contador);
        }
    }
}