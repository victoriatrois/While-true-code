import java.util.Scanner;

public class ClassificaNumeros {
    public static void main (String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int numeroAConferir;
        int quantidadeDeNegativos;
        int quantidadeDePositivos;
        int quantidadeDePares;
        int quantidadeDeImpares;
        
        numeroAConferir = 1;
        quantidadeDeNegativos = 0;
        quantidadeDePositivos = 0;
        quantidadeDePares = 0;
        quantidadeDeImpares = 0;
        
        System.out.println("Entre os valores que deseja classificar. Para sair, digite zero.");
        while (numeroAConferir != 0) {
            numeroAConferir = entrada.nextInt();
            
            if (numeroAConferir == 0) {
                System.out.print(quantidadeDePositivos + " - " + quantidadeDeNegativos + " - " + quantidadeDePares +  " - " + quantidadeDeImpares);
            } else {
                if ((numeroAConferir % 2 == 0) && (numeroAConferir != 0)) {
                    quantidadeDePares++;
                    
                    if (numeroAConferir > 0) {
                        quantidadeDePositivos++;
                    } else {
                        quantidadeDeNegativos++;
                    }
                } else {
                    quantidadeDeImpares++;
                    
                    if ((numeroAConferir > 0) && (numeroAConferir != 0)) {
                        quantidadeDePositivos++;
                    } else {
                        quantidadeDeNegativos++;
                    }
                }
            }
        }
    }
}