import java.util.Scanner;

public class EhPrimo {
    public static void main (String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int numeroAConferir;
        int divisor = 0;
        int testeSeDivide = 0;
        int totalDeDivisores = 2;
        
        numeroAConferir = entrada.nextInt();
        divisor = numeroAConferir / 2;
        if (numeroAConferir == 1) {
            System.out.print("não");
        } else if (numeroAConferir == 2) {
            System.out.print("sim");
        } else {
            while (divisor > 2) {
                testeSeDivide = numeroAConferir % divisor;
                if (testeSeDivide == 0) {
                    totalDeDivisores++;
                }
                divisor--;
            }
            if (totalDeDivisores == 2) {
                System.out.print("sim");
            } else {
                System.out.print("não");
            }
        }
    }
}