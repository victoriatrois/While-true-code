import java.util.Scanner;

public class Avaliacao02Atividade02 {
    public static void main (String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        int varA, varB, varC, i;
        varC = 0;
        
        System.out.println("Questao 02");
        System.out.println("Informe um valor inteiro positivo: ");
        varA = teclado.nextInt();
        System.out.println("Informe um valor inteiro positivo: ");
        varB = teclado.nextInt();
        i = varB;
        
        if ((varA < 0) || (varB < 0)) {
            System.out.println("entre dois números inteiros e positivos.");
        } else {
            if (varB == 0) {
                varC = 1;
            } else if (varB == 1) {
                varC = varA;
            } else {
                varC = varA;
                while (i > 1) {
                    varC *= varA;
                    i--;
                }
            }
        }
        System.out.println(varA + " elevado ao expoente " + varB + " é => " + varC);
    }
}