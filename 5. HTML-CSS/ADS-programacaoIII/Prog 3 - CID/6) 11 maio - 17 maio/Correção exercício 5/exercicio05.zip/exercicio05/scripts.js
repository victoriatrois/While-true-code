function validar() {
    var cnpj = document.getElementById('cnpj');
    var nome = document.getElementById('nome');
    var razao = document.getElementById('razao');
    var email = document.getElementById('email');
    var endereco = document.getElementById('endereco');
    var telefone = document.getElementById('telefone');
    var data = document.getElementById('data');
    var numFuncionarios = document.getElementById('numero_funcionarios');
    var faturamento = document.getElementById('faturamento');

    var ramoComercio = document.getElementById('ramoComercio');
    var ramoServico = document.getElementById('ramoServico');
    var ramoIndustria = document.getElementById('ramoIndustria');

    var retorno = true;

    //var ramo = document.getElementsByName('ramo'); Pegar os valores de um conjunto de radiobuttos ou checkbox com o name do input.

    if (cnpj.value == '') {
        alert('O campo CNPJ é de digitação obrigatória!!!');
        cnpj.style.backgroundColor = "#FF0000";
        cnpj.focus();
        retorno = false;
    } else {
        if (cnpj.value.length != 18) {
            alert('O campo CNPJ deve ter 18 caracteres!!!');
            cnpj.style.backgroundColor = "#FF0000";
            cnpj.focus();
            retorno = false;
        } else {
            var patternCNPJ = /^[0-9]{2}.[0-9]{3}.[0-9]{3}\/[0-9]{4}-[0-9]{2}$/;
            if (!patternCNPJ.test(cnpj.value)) {
                alert("Digite o CNPJ no formato 00.000.000/0000-00.");
                cnpj.style.backgroundColor = "#FF0000";
                cnpj.focus();
                retorno = false;
            } else {
                cnpj.style.backgroundColor = "";
            }   
        }
    }

    if (nome.value == '') {
        alert('O campo Nome Fantasia é de digitação obrigatória!!!');
        nome.style.backgroundColor = "#FF0000";
        nome.focus();
        retorno = false;
    } else {
        if (nome.value.length > 100) {
            alert('O campo Nome Fantasia deve ter no máximo 100 caracteres!!!');
            nome.style.backgroundColor = "#FF0000";
            nome.focus();
            retorno = false;
        } else {
            nome.style.backgroundColor = "";
        }
    }

    if (razao.value == '') {
        alert('O campo Razão Social é de digitação obrigatória!!!');
        razao.style.backgroundColor = "#FF0000";
        razao.focus();
        retorno = false;
    } else {
        if (razao.value.length > 150) {
            alert('O campo Razão Social deve ter no máximo 150 caracteres!!!');
            razao.style.backgroundColor = "#FF0000";
            razao.focus();
            retorno = false;
        } else {
            razao.style.backgroundColor = "";
        }
    }

    if (telefone.value == '') {
        alert('O campo telefone é de digitação obrigatória!!!');
        telefone.style.backgroundColor = "#FF0000";
        telefone.focus();
        retorno = false;
    } else {
        if (telefone.value.length != 14) {
            alert('O campo telefone deve ter 14 caracteres!!!');
            telefone.style.backgroundColor = "#FF0000";
            telefone.focus();
            retorno = false;
        } else {
            var patternFone = /^\([0-9]{2}\)[0-9]{5}-[0-9]{4}$/;
            if (!patternFone.test(telefone.value)) {
                alert("Digite o telefone no formato (00)00000-0000.");
                telefone.style.backgroundColor = "#FF0000";
                telefone.focus();
                retorno = false;
            } else {
                telefone.style.backgroundColor = "";
            }   
        }
    }

    if (email.value == '') {
        alert('O campo E-mail é de digitação obrigatória!!!');
        email.style.backgroundColor = "#FF0000";
        email.focus();
        retorno = false;
    } else {
        if (email.value.length > 100) {
            alert('O campo E-mail deve ter no máximo 100 caracteres!!!');
            email.style.backgroundColor = "#FF0000";
            email.focus();
            retorno = false;
        } else {
            email.style.backgroundColor = "";
        }
    }

    if (endereco.value == '') {
        alert('O campo Endereço é de digitação obrigatória!!!');
        endereco.style.backgroundColor = "#FF0000";
        endereco.focus();
        retorno = false;
    } else {
        endereco.style.backgroundColor = "";
    }

    if (data.value == '') {
        alert('O campo Data de Fundação é de digitação obrigatória!!!');
        data.style.backgroundColor = "#FF0000";
        data.focus();
        retorno = false;
    } else {
        data.style.backgroundColor = "";
    }

    // Obrigatoriedade do Ramo de Atuação
    if (!ramoComercio.checked && !ramoServico.checked && !ramoIndustria.checked) {
        alert('O campo Ramo de Atuação é de marcação obrigatória!!!');
        retorno = false;
    }

    if (numFuncionarios.value == '' || isNaN(numFuncionarios.value) || (parseInt(numFuncionarios.value) < 0)) {
        alert('O campo Núemro de Funcionários deve ser um número positivo!!!');
        numFuncionarios.style.backgroundColor = "#FF0000";
        numFuncionarios.focus();
        retorno = false;
    } else {
        if (faturamento.value == '' || isNaN(faturamento.value) || (parseFloat(faturamento.value) < 0)) {
            alert('O campo Faturamento Anual deve ser um número positivo!!!');
            faturamento.style.backgroundColor = "#FF0000";
            faturamento.focus();
            retorno = false;
        } else {
            if (parseFloat(faturamento.value) > 360000) {
                alert('Os dados de faturamento não representam uma microempresa.');
                faturamento.style.backgroundColor = "#FF0000";
                faturamento.focus();
                retorno = false;
            } else {
                if (ramoIndustria.checked && parseInt(numFuncionarios.value) > 19) {
                    alert('Os dados de número de funcionários não representam uma microempresa.');
                    numFuncionarios.style.backgroundColor = "#FF0000";
                    numFuncionarios.focus();
                    retorno = false;
                } else {
                    if ((ramoComercio.checked || ramoServico.checked)  && parseInt(numFuncionarios.value) > 9) {
                        alert('Os dados de número de funcionários não representam uma microempresa.');
                        numFuncionarios.style.backgroundColor = "#FF0000";
                        numFuncionarios.focus();
                        retorno = false;
                    } else {
                        numFuncionarios.style.backgroundColor = "";
                        faturamento.style.backgroundColor = "";
                    }
                }
            }
        }
    }

    return retorno;
}