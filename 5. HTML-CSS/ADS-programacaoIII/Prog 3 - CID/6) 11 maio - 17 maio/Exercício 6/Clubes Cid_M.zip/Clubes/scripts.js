function validar() {

    var retorno = true;

    $("#erros li").remove();

    if ($("#sigla").val() == "") {
        retorno = erroValidacao("O campo Sigla é obrigatório!", "#sigla");
    } else {
        if ($("#sigla").val().length > 3) {
            retorno = erroValidacao("A sigla deve ter no máximo 3 caracteres!", "#sigla");
        } else {
            $("#sigla").css("background-color","");  
        }
    }

    if ($("#nome").val() == "") {
        retorno = erroValidacao("O campo Nome é obrigatório!", "#nome");
    } else {
        if ($("#nome").val().length > 100) {
            retorno = erroValidacao("O campo Nome deve ter no máximo 100 caracteres!", "#nome");
        } else {
            $("#nome").css("background-color","");
        }
    }

    if ($("#data").val() == ""){
        retorno = erroValidacao("O campo Data é obrigatório!", "#data");
    }else{
        $("#data").css("background-color","");
    }

    var estadoSelecionado = $("#estado").val();
    var municipioSelecionado = $("#municipio").val();

    if (!estadoSelecionado || estadoSelecionado === "" || estadoSelecionado == "none") {
        retorno = erroValidacao("O campo Estado é obrigatório!", "#estado");
    } else {
        $("#estado").css("background-color","");
    }

    if (!municipioSelecionado || municipioSelecionado === "" || municipioSelecionado === "default" ) {
        retorno = erroValidacao("O campo Município é obrigatório!", "#municipio");
    } else {
        $("#municipio").css("background-color","");
    }

    return retorno;
}

function erroValidacao(msg, element){
    $("#erros").append("<li>" + msg + "</li>");
    $(element).css("background-color","#FF0000");
    $(element).focus();
    return false;
}


function callService() {
    var url = "https://servicodados.ibge.gov.br/api/v1/localidades/estados/";

    var selectMunicipio = $("#municipio");
    var selectEstado = $("#estado");

    var estado = selectEstado.val();

    selectMunicipio.empty();

    if(estado){
        var municipioUrl = url + estado + "/municipios";
        var params = '{}';

        $.ajax({
            type: "GET",
            url: municipioUrl,
            data: params,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function(data) {
                $.each(data, function (i, municipio) {
                    var option = $('<option>').text(municipio.nome).val(municipio.id)
                    selectMunicipio.append(option);
                });
            },
        });
    }
}


