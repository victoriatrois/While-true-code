function validar() {
    var retorno = true;

    $("#erros li").remove();

    if ($("#cnpj").val() == '') {
        $("#erros").append("<li>O campo CNPJ é de digitação obrigatória!!!</li>");
        $("#cnpj").css("background-color","#FF0000");
        $("#cnpj").focus();
        retorno = false;
    } else {
        if ($("#cnpj").val().length != 18) {
            $("#erros").append("<li>O campo CNPJ deve ter 18 caracteres!!!</li>");
            $("#cnpj").css("background-color","#FF0000");
            $("#cnpj").focus();
            retorno = false;
        } else {
            var patternCNPJ = /^[0-9]{2}.[0-9]{3}.[0-9]{3}\/[0-9]{4}-[0-9]{2}$/;
            if (!patternCNPJ.test($("#cnpj").val())) {
                $("#erros").append("<li>Digite o CNPJ no formato 00.000.000/0000-00.</li>");
                $("#cnpj").css("background-color","#FF0000");
                $("#cnpj").focus();
                retorno = false;
            } else {
                $("#cnpj").css("background-color","");
            }   
        }
    }

    if ($("#nome").val() == '') {
        $("#erros").append("<li>O campo Nome Fantasia é de digitação obrigatória!!!</li>");
        $("#nome").css("background-color","#FF0000");
        $("#nome").focus();
        retorno = false;
    } else {
        if ($("#nome").val().length > 100) {
            $("#erros").append("<li>O campo Nome Fantasia deve ter no máximo 100 caracteres!!!</li>");
            $("#nome").css("background-color","#FF0000");
            $("#nome").focus();
            retorno = false;
        } else {
            $("#nome").css("background-color","");
        }
    }

    if ($("#numero_funcionarios").val() == '' || isNaN($("#numero_funcionarios").val()) || (parseInt($("#numero_funcionarios").val()) < 0)) {
        $("#erros").append("<li>O campo Núemro de Funcionários deve ser um número positivo!!!</li>");
        $("#numero_funcionarios").css("background-color","#FF0000");
        $("#numero_funcionarios").focus();
        retorno = false;
    } else {
        if ($("#faturamento").val() == '' || isNaN($("#faturamento").val()) || (parseFloat($("#faturamento").val()) < 0)) {
            $("#erros").append("<li>O campo Faturamento Anual deve ser um número positivo!!!</li>");
            $("#faturamento").css("background-color","#FF0000");
            $("#faturamento").focus();
            retorno = false;
        } else {
            if (parseFloat($("#faturamento").val()) > 360000) {
                $("#erros").append("<li>Os dados de faturamento não representam uma microempresa.</li>");
                $("#faturamento").css("background-color","#FF0000");
                $("#faturamento").focus();
                retorno = false;
            } else {
                if ($("#ramoIndustria").prop("checked") && parseInt($("#numero_funcionarios").val()) > 19) {
                    $("#erros").append("<li>Os dados de número de funcionários não representam uma microempresa.</li>");
                    $("#numero_funcionarios").css("background-color","#FF0000");
                    $("#numero_funcionarios").focus();
                    retorno = false;
                } else {
                    if (($("#ramoComercio").prop("checked") || $("#ramoServico").prop("checked"))  && parseInt($("#numero_funcionarios").val()) > 9) {
                        $("#erros").append("<li>Os dados de número de funcionários não representam uma microempresa.</li>");
                        $("#numero_funcionarios").css("background-color","#FF0000");
                        $("#numero_funcionarios").focus();
                        retorno = false;
                    } else {
                        $("#numero_funcionarios").css("background-color","");
                        $("#faturamento").css("background-color","");
                    }
                }
            }
        }
    }

    return retorno;
}


function callService() {
    //var params = '{"cep":"valor"}';
    var params = '{}';
    $.ajax({
        type: "GET",
        url: "https://brasilapi.com.br/api/cep/v1/"+$("#cep").val(),
        data: params,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function(msg, status) {
            $("#logradouro").val(msg.street); 
            $("#bairro").val(msg.neighborhood); 
            $("#cidade").val(msg.city); 
            $("#estado").val(msg.state);
        },
        error: function(xhr, msg, e) {
            alert(xhr.responseJSON.message);
            $("#logradouro").val("");
        }
    });
}


