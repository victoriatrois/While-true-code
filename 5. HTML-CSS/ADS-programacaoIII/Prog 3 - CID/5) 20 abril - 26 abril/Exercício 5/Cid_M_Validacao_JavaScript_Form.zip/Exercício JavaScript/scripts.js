$(document).ready(function() {
    $('#cnpj').mask('00.000.000/0000-00', {reverse: false});
    $('#telefone').mask('(00)00000-0000', {reverse: false});
    $('#datafundacao').mask('00/00/0000', {reverse: false});
});

const patternData = /^[0-9]{2}\/[0-9]{2}\/[0-9]{4}$/; // expressão regular
const patternCNPJ = /^[0-9]{2}[\.][0-9]{3}[\.][0-9]{3}[\/][0-9]{4}[-][0-9]{2}$/;

const form = document.querySelector("#form");

const cnpj = document.querySelector("#cnpj");
const nomefantasia = document.querySelector("#nomefantasia");
const razaosocial = document.querySelector("#razaosocial");
const telefone = document.querySelector("#telefone");
const email = document.querySelector("#email");

const data = document.querySelector("#datafundacao");

const opc1 = document.querySelector("#opc1");
const opc2 = document.querySelector("#opc2");
const opc3 = document.querySelector("#opc3");

const numerofunc = document.getElementById('numerofunc');
const fatanual = document.getElementById('fatanual');

form.addEventListener("submit", (event) => {
    event.preventDefault();

    let validacao = true;

    // CNPJ
    if(cnpj.value === "" || !patternCNPJ.test(cnpj.value) || cnpj.value.length > 19){
        validacao = false;
        cnpj.style = "border-color: red;"
    }

    // Nome Fantasia
    if(nomefantasia.value === "" || nomefantasia.value.length > 100){
        validacao = false;
        nomefantasia.style = "border-color: red;"
    }

    //Razão Social
    if(razaosocial.value === "" || razaosocial.value.length > 150){
        validacao = false;
        razaosocial.style = "border-color: red;"
    }

    // Telefone
    if(telefone.value === "" || telefone.value.length > 14){
        validacao = false;
        telefone.style = "border-color: red;"
    }

    // Email
    if(email.value === "" || email.value.length > 100){
        validacao = false;
        email.style = "border-color: red;"
    }

    // Data da Fundação
    if(data.value === "" || !patternData.test(data.value) || data.value.length > 10){
        validacao = false;
        data.style = "border-color: red;"
    }

    // Ramo de Atuação
    if(!opc1.checked && !opc2.checked && !opc3.checked){
        alert('Selecione um ramo')
        validacao = false;
    }

    if(validacao){
        if (fatanual.value > 360000 || 
            (numerofunc.value > 9 && (opc1.checked || opc2.checked)) ||
            (numerofunc.value > 19 && opc3.checked)) {
            alert("Os dados de faturamento e número de funcionários não representam uma microempresa.");
        }else{
            alert('envio concluído!');
            form.submit();
        }
    }else{
        alert('Campos preenchidos irregularmente.');
    }
});
