$(document).ready(function() {

    // Popula a caixa de seleção de estados
    $.getJSON("https://servicodados.ibge.gov.br/api/v1/localidades/estados", function(data) {
      var options = "<option value='none'>Selecione um estado</option>";
      var regions = {};

      // Agrupa os estados por região
      $.each(data, function(index, estado) {
        var region = estado.regiao.nome;
        if (!regions[region]) {
          regions[region] = [];
        }
        regions[region].push(estado);
      });

      // Popula as opções da caixa de seleção de estados por região
      $.each(regions, function(region, estados) {
        options += "<optgroup label='" + region + "'>";
        $.each(estados, function(index, estado) {
          options += "<option value='" + estado.sigla + "'>" + estado.nome + "</option>";
        });
        options += "</optgroup>";
      });

      $("#estado").html(options);
    });

    // Atualiza as cidades quando um estado é selecionado
    $("#estado").on("change", function() {
      var uf = $(this).val();
      if (uf) {
        var url = "https://servicodados.ibge.gov.br/api/v1/localidades/estados/" + uf + "/municipios";

        $.getJSON(url, function(data) {
          var options = "<option value='none'>Selecione uma cidade</option>";

          // Popula as opções da caixa de seleção de cidades
          $.each(data, function(index, cidade) {
            options += "<option value='" + cidade.nome + "'>" + cidade.nome + "</option>";
          });

          $("#cidade").html(options);
        });
      } else {
        $("#cidade").html("<option value=''>Selecione um estado primeiro</option>");
      }
    });
  });

  $(document).ready(function() {
    $('#cnpj').mask('00.000.000/0000-00', {reverse: false});
    $('#data').mask('00/00/0000', {reverse: false});
  });

function validar() {

    const patternCPF = /^(\d{3})\.(\d{3})\.(\d{3})-(\d{2})$/;

    var retorno = true;

    $("#erros li").remove();

    // validação de cpf
    if($("#cpf").val() === "" || !patternCPF.test($("#cpf").val()) || $("#cpf").val().length > 14){
        retorno = erroValidacao("CPF Inválido!", "#cpf")
    }else{
        $("#cpf").css("background-color","");
    }

    // validação de nome
    if ($("#nome").val() == "") {
        retorno = erroValidacao("O campo Nome é obrigatório!", "#nome");
    } else {
        if ($("#nome").val().length > 100) {
            retorno = erroValidacao("O campo Nome deve ter no máximo 100 caracteres!", "#nome");
        } else {
            $("#nome").css("background-color","");
        }
    }

    // validação de sexualidade
    if ($("input[name='sexo']:checked").length === 0) {
        $("#erros").append("<li>Por favor, escolha uma opção de sexualidade</li>");
    }

    // validação de data
    if ($("#data").val() == ""){
        retorno = erroValidacao("O campo Data é obrigatório!", "#data");
    }else{
        $("#data").css("background-color","");
    }

    // validação de endereço
    if ($("#endereco").val() == "") {
        retorno = erroValidacao("O campo Endereco é obrigatório!", "#endereco");
    } else {
        if ($("#endereco").val().length > 200) {
            retorno = erroValidacao("O campo Endereco deve ter no máximo 100 caracteres!", "#endereco");
        } else {
            $("#endereco").css("background-color","");
        }
    }

    var estadoSelecionado = $("#estado").val();
    var cidadeSelecionada = $("#cidade").val();

    // validação de estado e cidade
    if (!estadoSelecionado || estadoSelecionado === "" || estadoSelecionado == "none") {
        retorno = erroValidacao("Escolha um estado!", "#estadoo");
    }else{
        $("#estadoo").css("background-color","");
    }

    if (!cidadeSelecionada || cidadeSelecionada === "" || cidadeSelecionada === "none" ) {
        retorno = erroValidacao("Escolha uma cidade!", "#cidade");
    }else{
        $("#cidade").css("background-color","");
    }

    return retorno;
}

function erroValidacao(msg, element){
    $("#erros").append("<li>" + msg + "</li>");
    $(element).css("background-color","#3083ff");
    $(element).focus();
    return false;
}


