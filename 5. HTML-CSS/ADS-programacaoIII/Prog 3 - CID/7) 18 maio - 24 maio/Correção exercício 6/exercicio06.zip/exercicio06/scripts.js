function validar() {
    $("#erros li").remove();

    if ($("#sigla").val() == '') {
        $("#erros").append("<li>Sigla deve ser informada!!!</li>");
        $("#sigla").focus();
        return false;
    } else {
        $("#sigla").val($("#sigla").val().toUpperCase());
        if ($("#sigla").val().length > 3) {
            $("#erros").append("<li>Sigla deve ter no máximo três caracteres!!!</li>");
            $("#sigla").focus();
            return false;
        }
    }

    return false;
}

function popularMunicipio() {
    var params = '{}';
    $.ajax({
        type: "GET",
        url: "https://servicodados.ibge.gov.br/api/v1/localidades/estados/"+$("#estado").val()+"/municipios",
        data: params,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function(msg, status) {    
            $("#municipio li.cid").remove();        
            for (var i=0; i<msg.length; i++) {
                $("#municipio").append("<option class=\"cid\" value=\""+msg[i].id+"\">"+msg[i].nome+"</option>");
            }
            
        },
        error: function(xhr, msg, e) {
            alert(xhr.responseJSON.message);
            $("#municipio li.cid").remove();
        }
    });
}